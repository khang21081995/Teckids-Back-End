// var module1 = require("./module1");
// var module3 = require("./module3");
//
// console.log(module1.age);
// module3(14);
// console.log(module1.age);

var path = require("path");
console.log(path.join("", ""));
