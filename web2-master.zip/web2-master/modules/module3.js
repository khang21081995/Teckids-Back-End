var module1 = require("./module1");

module.exports = function(newAge){
  module1.age = newAge;
}
