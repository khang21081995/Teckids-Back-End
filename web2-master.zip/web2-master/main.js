/**
 * New node file
 */
var fileHelper = require("./fileHelper");
// var Static = require("./Statistic");
//fileHelper.readFile("./data.txt", function(data){
//  console.log(data);
//});

// Static.output("data.txt","output.txt");

fileHelper.readFile("data.txt");
